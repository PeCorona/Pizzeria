import React from "react";


export function PizzaList(pizzas){
  return(
    <h2>
  
      {JSON.stringify(pizzas)}
  
    </h2> 
  )
}
