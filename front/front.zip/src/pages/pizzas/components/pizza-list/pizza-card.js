import React from "react";

export function PizzaCard(pizza) {
  return (
    <article>

      <h2>
          
      </h2>

    </article>
  );
}
